#include <windows.h>

#include <stdlib.h>
#include <time.h>

#include <stdio.h>

// amount of horizontal tiles
#define GRID_HEIGHT 250
// amount of veritical tiles
#define GRID_WIDTH 250
BYTE GAME_GRID[GRID_HEIGHT][GRID_WIDTH] = {0};
// height and width of a single tile
#define TILE_SIZE 5
// height in pixels
#define PIXELS_HEIGHT (GRID_HEIGHT * TILE_SIZE)
// width in pixels
#define PIXELS_WIDTH (GRID_WIDTH * TILE_SIZE)

#define GRID_AT(grid, x, y) (grid[y][x])

#define COMP_POINT(p1, p2) (((p1)->x == (p2)->x) && ((p1)->y == (p2)->y))

typedef enum TILE_RGB
{
    NoneTileRGB = (COLORREF)RGB(0, 0, 0),
    BorderTileRGB = (COLORREF)RGB(255, 255, 255),
    SnakeTileRGB = (COLORREF)RGB(0, 255, 0),
    AppleTileRGB = (COLORREF)RGB(255, 0, 0),
} TileRGB;

typedef enum TILE_TYPE
{
    NoneTile,
    BorderTile,
    SnakeTile,
    AppleTile,
} TileType;

typedef enum SNAKE_DIRECTION
{
    Up,
    Left,
    Down,
    Right,
} SnakeDirections;

typedef struct Point
{
    int x;
    int y;
} Point;
typedef struct POINT_LIST_NODE
{
    struct POINT_LIST_NODE *next;
    Point *point;
} PointList;

Point *ApplePoint;
PointList *SnakePoints;
BYTE SnakeDirection = Up;

int GetTileRGB(TileType tileType)
{
    switch (tileType)
    {
    case NoneTile:
        return NoneTileRGB;
    case BorderTile:
        return BorderTileRGB;
    case SnakeTile:
        return SnakeTileRGB;
    case AppleTile:
        return AppleTileRGB;
    default:
        return RGB(128, 128, 128);
    }
}

// random number from low to high including high
// low <= n <= high
int RandomInt(int low, int high)
{
    return (rand() % (high - low + 1)) + low;
}

void NewApple(void)
{
    int randomAppleX = RandomInt(1, GRID_WIDTH - 2);
    int randomAppleY = RandomInt(1, GRID_HEIGHT - 2);
    BOOL success = TRUE;
    while (1)
    {
        for (PointList *i = SnakePoints; i; i = i->next)
        {
            if ((i->point->x == randomAppleX) && (i->point->y == randomAppleY))
            {
                int randomAppleX = RandomInt(1, GRID_WIDTH - 2);
                int randomAppleY = RandomInt(1, GRID_HEIGHT - 2);
                success == FALSE;
                break;
            }
        }
        if (success == TRUE)
        {
            break;
        }
    }
    ApplePoint->x = randomAppleX;
    ApplePoint->y = randomAppleY;
    GRID_AT(GAME_GRID, ApplePoint->x, ApplePoint->y) = AppleTile;
}

void InitializeGame(void)
{
    SnakePoints = (PointList *)GlobalAlloc(GMEM_FIXED, sizeof(*SnakePoints));
    SnakePoints->next = NULL;
    SnakePoints->point = (Point *)GlobalAlloc(GMEM_FIXED, sizeof(*SnakePoints->point));
    ApplePoint = (Point *)GlobalAlloc(GMEM_FIXED, sizeof(*ApplePoint));

    int randomSnakeX = RandomInt(1, GRID_WIDTH - 2);
    int randomSnakeY = RandomInt(1, GRID_HEIGHT - 2);
    int randomAppleX = RandomInt(1, GRID_WIDTH - 2);
    int randomAppleY = RandomInt(1, GRID_HEIGHT - 2);
    while (randomAppleX == randomSnakeX)
    {
        randomAppleX = RandomInt(1, GRID_WIDTH - 2);
    }
    while (randomAppleY == randomSnakeY)
    {
        randomAppleY = RandomInt(1, GRID_HEIGHT - 2);
    }
    for (int y = 0; y < GRID_HEIGHT; y++)
    {
        for (int x = 0; x < GRID_WIDTH; x++)
        {
            if (x == 0 || y == 0 || x == GRID_WIDTH - 1 || y == GRID_HEIGHT - 1)
            {
                GRID_AT(GAME_GRID, x, y) = BorderTile;
            }
        }
    }
    ApplePoint->x = randomAppleX;
    ApplePoint->y = randomAppleY;

    SnakePoints->point->x = randomSnakeX;
    SnakePoints->point->y = randomSnakeY;

    GRID_AT(GAME_GRID, randomAppleX, randomAppleY) = AppleTile;
    GRID_AT(GAME_GRID, randomSnakeX, randomSnakeY) = SnakeTile;

    SnakeDirection = RandomInt(0, 3);
}

void GameStep(HWND hwnd)
{
    // Snake has to take a step and update the game grid data

    PointList *newList = (PointList *)GlobalAlloc(GMEM_FIXED, sizeof(*SnakePoints));
    if (!newList)
    {
        printf("afdsafsadfas");
        return;
    }
    newList->next = NULL;
    newList->point = (Point *)GlobalAlloc(GMEM_FIXED, sizeof(*SnakePoints->point));
    if (!newList->point)
    {
        printf("afdsafsadfas");
        return;
    }

    switch (SnakeDirection)
    {
    case Up:
        newList->point->x = SnakePoints->point->x;
        newList->point->y = SnakePoints->point->y - 1;
        break;
    case Down:
        newList->point->x = SnakePoints->point->x;
        newList->point->y = SnakePoints->point->y + 1;
        break;
    case Left:
        newList->point->x = SnakePoints->point->x - 1;
        newList->point->y = SnakePoints->point->y;
        break;
    case Right:
        newList->point->x = SnakePoints->point->x + 1;
        newList->point->y = SnakePoints->point->y;
        break;
    }

    newList->next = SnakePoints;
    SnakePoints = newList;
    newList = NULL;
    // printf("%p\n", SnakePoints);
    // printf("%p\n", SnakePoints->next);
    // Events to handle:
    //     Snake touches apple
    //     Snake touches border
    //     Snake touches snake
    if (GRID_AT(GAME_GRID, SnakePoints->point->x, SnakePoints->point->y) == BorderTile)
    {
        // GameOver();
        PostMessage(hwnd, WM_CLOSE, 0, 0);
        return;
    }
    if (GRID_AT(GAME_GRID, SnakePoints->point->x, SnakePoints->point->y) == SnakeTile)
    {
        // GameOver();
        PostMessage(hwnd, WM_CLOSE, 0, 0);
        return;
    }

    if (GRID_AT(GAME_GRID, SnakePoints->point->x, SnakePoints->point->y) == AppleTile)
    {
        NewApple();
    }
    else
    {
        PointList *oneBeforeLast = SnakePoints;
        while (oneBeforeLast->next && oneBeforeLast->next->next)
        {
            oneBeforeLast = oneBeforeLast->next;
        }
        GRID_AT(GAME_GRID, oneBeforeLast->next->point->x, oneBeforeLast->next->point->y) = NoneTile;
        GlobalFree(oneBeforeLast->next);
        oneBeforeLast->next = NULL;
    }
    GRID_AT(GAME_GRID, SnakePoints->point->x, SnakePoints->point->y) = SnakeTile;
    InvalidateRect(hwnd, NULL, FALSE);
    SendMessage(hwnd, WM_PAINT, 0, 0);
}

clock_t lastGameStep = 0;
DWORD WINAPI GameLoop(LPVOID lpParam)
{
    while (1)
    {
        if (SnakeDirection != 255)
        {
            GameStep((HWND)lpParam);
            Sleep(5);
        }
    }
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_KEYDOWN:
        if ((lParam & 0x40000000) == 0)
        {
            switch (wParam)
            {
            case 'W':
                if (SnakeDirection != Down)
                    SnakeDirection = Up;
                break;
            case 'A':
                if (SnakeDirection != Right)
                    SnakeDirection = Left;
                break;
            case 'S':
                if (SnakeDirection != Up)
                    SnakeDirection = Down;
                break;
            case 'D':
                if (SnakeDirection != Left)
                    SnakeDirection = Right;
                break;
            default:
                break;
            }
            Beep(100, 1);
        }
        break;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        RECT tileRect;

        // TODO: optimize this because i only really need 3 rectangles and the snake
        // for (int y = 0; y < GRID_HEIGHT; y++)
        // {
        //     for (int x = 0; x < GRID_WIDTH; x++)
        //     {
        //         tileRect.left = x * TILE_SIZE;
        //         tileRect.top = y * TILE_SIZE;
        //         tileRect.right = tileRect.left + TILE_SIZE;
        //         tileRect.bottom = tileRect.top + TILE_SIZE;
        //         TileType tileType = GRID_AT(GAME_GRID, x, y);
        //         TileRGB tileRGB = GetTileRGB(tileType);
        //         HBRUSH hBrush = CreateSolidBrush(tileRGB);
        //         FillRect(hdc, &tileRect, hBrush);
        //         DeleteObject(hBrush);
        //     }
        // }
        // Border
        // tileRect.left = 0;
        // tileRect.top = 0;
        // tileRect.right = GRID_WIDTH * TILE_SIZE;
        // tileRect.bottom = GRID_HEIGHT * TILE_SIZE;
        // HBRUSH hBrush = CreateSolidBrush(BorderTileRGB);
        // FillRect(hdc, &tileRect, hBrush);
        // DeleteObject(hBrush);

        // empty space
        tileRect.left = TILE_SIZE;
        tileRect.top = TILE_SIZE;
        tileRect.right = (GRID_WIDTH - 1) * TILE_SIZE;
        tileRect.bottom = (GRID_HEIGHT - 1) * TILE_SIZE;
        HBRUSH hBrush = CreateSolidBrush(NoneTileRGB);
        FillRect(hdc, &tileRect, hBrush);
        DeleteObject(hBrush);

        // apple
        tileRect.left = ApplePoint->x * TILE_SIZE;
        tileRect.top = ApplePoint->y * TILE_SIZE;
        tileRect.right = tileRect.left + TILE_SIZE;
        tileRect.bottom = tileRect.top + TILE_SIZE;
        hBrush = CreateSolidBrush(AppleTileRGB);
        FillRect(hdc, &tileRect, hBrush);
        DeleteObject(hBrush);

        for (PointList *i = SnakePoints; i; i = i->next)
        {
            tileRect.left = i->point->x * TILE_SIZE;
            tileRect.top = i->point->y * TILE_SIZE;
            tileRect.right = tileRect.left + TILE_SIZE;
            tileRect.bottom = tileRect.top + TILE_SIZE;
            hBrush = CreateSolidBrush(SnakeTileRGB);
            FillRect(hdc, &tileRect, hBrush);
            DeleteObject(hBrush);
        }

        EndPaint(hwnd, &ps);
    }
    break;
    case WM_DESTROY:
        DestroyWindow(hwnd);
        break;
    case WM_QUIT:
        PostQuitMessage(0);
    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
        break;
    }
}

void AttachConsoleToWindow()
{
    // Allocate a new console window
    AllocConsole();

    // Redirect standard input, output, and error streams
    freopen("CONOUT$", "w", stdout);
    freopen("CONIN$", "r", stdin);
    freopen("CONOUT$", "w", stderr);

    printf("Console attached successfully!\n");
}

const char mainClassName[] = "SnakeWindowClass";
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    srand((unsigned int)time(NULL));
    // AttachConsoleToWindow();

    WNDCLASSEX wc = {
        .hInstance = hInstance,
        .lpszClassName = mainClassName,
        .lpfnWndProc = WndProc,
        .lpszMenuName = NULL,
        .style = 0,
        .hIcon = LoadIcon(NULL, IDI_APPLICATION),
        .hIconSm = LoadIcon(NULL, IDI_APPLICATION),
        .cbSize = sizeof(wc),
        .cbClsExtra = 0,
        .cbWndExtra = 0,
        .hbrBackground = (HBRUSH)(COLOR_WINDOW + 1),
        .hCursor = LoadCursor(hInstance, IDC_ARROW),
    };

    if (!RegisterClassEx(&wc))
    {
        MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    DWORD windowStyle = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU;

    // calculate the position for window centering
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    int startX = (screenWidth - PIXELS_WIDTH) / 2;
    int startY = (screenHeight - PIXELS_HEIGHT) / 2;

    RECT wndRect = {0, 0, PIXELS_WIDTH, PIXELS_HEIGHT};
    AdjustWindowRect(&wndRect, windowStyle, FALSE);

    int windowWidth = wndRect.right - wndRect.left;
    int windowHeight = wndRect.bottom - wndRect.top;

    HWND hwnd = CreateWindowEx(
        0,
        mainClassName,
        "Snake",
        windowStyle,
        startX, startY, windowWidth, windowHeight,
        NULL, NULL, hInstance, NULL);
    if (!hwnd)
    {
        MessageBox(NULL, "Window Creation Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    InitializeGame();
    HANDLE hThread;
    DWORD threadID;
    hThread = CreateThread(
        NULL,
        0,
        GameLoop,
        hwnd,
        0,
        &threadID);
    if (!hThread)
    {
        MessageBox(hwnd, "The program failed to create a thread", "Fatal Error", MB_OK | MB_ICONERROR);
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
    MSG msg;
    while (GetMessage(&msg, hwnd, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    CloseHandle(hThread);
    return msg.wParam;
}